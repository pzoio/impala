package interfaces;

public interface MessageService {

	public String getMessage();
	
}
