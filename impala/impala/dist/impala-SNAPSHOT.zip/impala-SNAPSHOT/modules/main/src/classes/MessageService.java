package classes;

public interface MessageService {

	public String getMessage();
	
}
