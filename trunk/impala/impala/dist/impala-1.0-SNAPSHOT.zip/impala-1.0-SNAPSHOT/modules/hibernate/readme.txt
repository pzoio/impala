Follow the instructions in http://code.google.com/p/impala/wiki/AddingModulesHibernate
once you have successfully set up this module through the `ant newmodule` script.