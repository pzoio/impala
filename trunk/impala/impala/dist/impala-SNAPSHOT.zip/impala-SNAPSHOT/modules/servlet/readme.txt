1) Add 
,servlet module name to project.list

{{{
project.list=main,module1,web,servlet1
}}}


